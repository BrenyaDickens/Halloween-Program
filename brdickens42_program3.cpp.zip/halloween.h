/*
   Title:    halloween.h
   Author:   Brenya Dickens
   Date:  	 November 6, 2024
   Purpose:  
*/

#ifndef HALLOWEEN_H 
#define HALLOWEEN_H // header defintion
// All libraries needed:
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <limits>

using namespace std;
// All function prototypes:
int guestList(string[], int); // Guest list menu function
int manageAct(string[], int); // Activity menu function
int printMenu(); // Main menu print
void printFood(string[], int[]); // Printing 
void saveParty(string[], string[], string[], int[], int, int);

const int MAX_GUEST_ACT = 10; // Making these global variables because they're constants
const int FOOD_COUNT = 4; // Making this 4 becuase there were 4 statements in the example output.



#endif // end of the definition