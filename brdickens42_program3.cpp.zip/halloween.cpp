/*
Title:      brdickens42_program3.cpp
Author:     Brenya Dickens
Date:       10/31/2024
Purpose:    The purpose of this program is to manage a Halloween party.
*/

#include "halloween.h" // Header file - includes all of my libraries, contsants, and functions prototypes

int main() // Main function with do-while loop for the main menu page
{ 
   cout <<  "\n\n~Time to plan my awesome Halloween party!~" << endl ;
 
    int menuChoice; // Main menu Choice
    // Starting these ints at 0 so that the index starts at 0 when I use them for arrays: 
    int numGuests = 0; // Tracker for geusts
    int numActs = 0; // Tracker for Activities
    //Hard coding these food strings and ints because they will not be changed:
    string string1 = "Witch Finger Cookies"; 
    string string2 = "Zombie Meatloaf";
    string string3 = "Eyeball Punch";
    string string4 = "Spider Web Cupcakes";
    int food1 = 7;
    int food2 = 6;
    int food3 = 12;
    int food4 = 15;
    string guestsArray[MAX_GUEST_ACT]; // Array for guest names, max is the constant 10.
    string actArray[MAX_GUEST_ACT]; // Array for activities, uses the same constant 10.
    string foodArray[FOOD_COUNT] = {string1, string2, string3, string4}; // Arrary for the string  types of food 
    int foodAmountArray[FOOD_COUNT] = {food1, food2, food3, food4}; // Array for the number of food





    do
    {
        menuChoice = printMenu(); 

            switch (menuChoice) // switch case for the 5 options in this menu
            {
            
                case 1:
                    numGuests = guestList(guestsArray, numGuests); // Calling the function for the guest list menu
                    break;
                
                    case 2: 
                    numActs = manageAct(actArray, numActs); // Calling the function for the activity list menu
                    break;
                    case 3:
                    printFood(foodArray, foodAmountArray); // Calling a function to print the food arrays
                    break;
                    case 4:
                    saveParty(guestsArray, actArray, foodArray, foodAmountArray, numGuests, numActs); // Calling a function to save all to file
                    break;
                    case 5: cout << "\nExiting Menu ";
                    break;
                    default: 
                    cout << "Your input is not valid." << endl;
                    break;
            }
    }      
    while (menuChoice != 5); // When their choice IS 5, the program will end.


    cout <<  "Goodbye!" << endl;

    return 0;

}



/****************************************************************************************************************************
Manage Guest List*/

int guestList(string guestsArray[], int numGuests) // funtion defonition for guest menu
{
    string newName; // Varibale for the name the user is adding to the list
    int guestChoice; // Variable for the element in the array they want to access

    cout << "Guest List:" << endl; 
    for(int i = 0; i < numGuests; i++) // For loop to read out each line of a guest
        {
            cout << i+1 << ". " << guestsArray[i] << endl; 
        }


        do // do-while loop for the guest menu 
        { 
            cout << "1. Add Guest\n2. Remove Guest\n3. Modify Guest\n4. Exit Guest Menu\nSelect a number choice." << endl;
            cin >> guestChoice;
            while(!cin || guestChoice < 1 || guestChoice > 4) // fancy way of user input validation
            {
                // validating user's input, making sure it's a number, and that it's between 1 and 4
                cin.clear();
                cin.ignore(numeric_limits<streamsize> :: max(), '\n'); 

                cout << "Your input was invalid.\n"; 
                cout << "Enter a number choice between 1 and 4: ";
                cout << "1. Add Guest\n2. Remove Guest\n3. Modify Guest\n4. Exit Guest Menu\nSelect a number choice." << endl;
                cin >> guestChoice; 
            }
                


                    switch(guestChoice) // Switch case inside this function for the guest sub-menu
                    {
                        case 1: // Adding a guest 
                            if (numGuests == MAX_GUEST_ACT) // When the max of guests has been reached, no more can be added
                            { 
                                cout << "Sorry the max amount of guests (10) has already been reached." << endl;
                            }

                            else 
                            {
                                cout << "\nEnter the name of the guest you want to add: " << endl;
                                cout << "Guest List:" << endl; // Displaying the list so far
                                for(int i = 0; i < numGuests; i++)
                                {
                                    cout << i+1 << ". " << guestsArray[i] << endl; // Doing i+1 so that it says the correct number, we don't want it to start at 0
                                }

                                cin.ignore(); // cin.ignore() before every getline
                                getline(cin, newName); 
                                guestsArray[numGuests] = newName; // This sets their input to the element 
                                numGuests++;  // Incrimenting the number of guests everytime a guest is added
                            }
                        break;
                        

                        case 2: // Removing a guest
                        
                            int removalChoice;
                            
                            if (numGuests == 0) // When there are no guests in the arrary
                            { 
                                cout << "Sorry there are no guests to be removed." << endl; 
                            }

                            else 
                            {
                                cout << "Which guest would you like to remove? Enter in an number." << endl; 
                                cout << "Guest List:" << endl; // Displaying the guests we have so far
                                for(int i = 0; i < numGuests; i++)
                                {
                                    cout << i+1 << ". " << guestsArray[i] << endl;
                                }
                                cin >> removalChoice;
                                while (!cin|| removalChoice < 1 || removalChoice > numGuests) // Validating user input

                                {
                                    cin.clear();
                                    cin.ignore(numeric_limits<streamsize> :: max(), '\n');

                                    cout << "Sorry, your input was not valid. Please enter in a valid number." << endl;
                                    cin >> removalChoice; // Another option for them to input 
                                }


                                for (int i = removalChoice - 1; i < numGuests; i++) // For loop for the removal
                                {
                                    guestsArray[i] = guestsArray[i+1]; // This will move each element from the right to the left.

                                }

                                numGuests--; // Decrementing the number of guests every time a guest is removed

                            }

                        break;
                        

                        case 3: // Modify Guest
                        
                            int modifyGuestChoice;

                            if (numGuests == 0) // When there are no guests in the arrary to modify
                                { 
                                    cout << "Sorry there are no guests to be modified." << endl;
                                }

                                else 
                                {
                                    cout << "Which guest would you like to modify? Enter in an number." << endl;
                                    cout << "Guest List:" << endl; // Guest list so far
                                    for(int i = 0; i < numGuests; i++)
                                    {
                                        cout << i+1 << ". " << guestsArray[i] << endl; // Correct numbering for the list
                                    }

                                    cin >> modifyGuestChoice;

                                    while (modifyGuestChoice < 1 || modifyGuestChoice > numGuests) // Validating user input
                                    {
                                        cout << "Sorry your input was not valid." << endl;
                                        cin >> modifyGuestChoice;

                                    }
                                    cout << "What would you like the change the name to?" << endl;
                                    cin.ignore();
                                    getline(cin, (guestsArray [modifyGuestChoice- 1])); 
                                }                                

                        break;


                    case 4: 
                        cout << "Exiting Activities Menu." << endl; // If they choose option 4 they can leave the menu after seeing this.
                    break;

                            
                    default: 
                    {
                        cout << "Your input was not a valid option." << endl; 
                    }

                        break;
                    }
        } while (guestChoice != 4); // The do-while loop goes when they do not choose 4 (to exit)

    return numGuests;
}




 // Print Menu Function
int printMenu()
{
    int menuChoice;
    cout << " \n\n1. Manage Guest List\n2. Manage Activities\n3. Manage Food\n4. Save Party to File\n5. Exit Party Planning " << endl;
    cin >> menuChoice;
    while(!cin || menuChoice < 1 || menuChoice > 5)
    {
        // validating user's input, making sure it's a number, and that it's between 1 and 5
        cin.clear();
        cin.ignore(numeric_limits<streamsize> :: max(), '\n'); 

        cout << "Sorry, your input was invalid.\n"; 
        cout << "Enter a number choice between 1 and 5: ";
        cout << "\n\n1. Manage Guest List\n2. Manage Activities\n3. Manage Food\n4. Save Party to File\n5. Exit Party Planning " << endl;
        cin >> menuChoice;

    }

        return menuChoice;

}




/****************************************************************************************************************************
Manage Activites*/

int manageAct(string actArray[], int numActs) // Defintion of the function for activity menu

{  
    string newActivity; 
    int activityChoice;
    cout << "Activity List:" << endl;
    for(int i = 0; i < numActs; i++) // For loop to read off the activity list
        {
            cout << i+1 << ". " << actArray[i] << endl;
        }
    do 
    {

    
        cout << "1. Add Activity\n2. Remove Activity\n3. Modify Guest\n4. Exit Activity Menu\nSelect a number choice." << endl;
        cin >> activityChoice;
        while(!cin || activityChoice < 1 || activityChoice > 4) 
        {
            // Validating user's input, making sure it's a number, and that it's between 1 and 4
            cin.clear();
            cin.ignore(numeric_limits<streamsize> :: max(), '\n'); 

            cout << "Your input was invalid.\n"; 
            cout << "Enter a number choice between 1 and 4: ";
            cin >> activityChoice;
        }



        


            switch(activityChoice)
            {
            case 1: // Adding an activity

                if (numActs == MAX_GUEST_ACT) // When the max of activities has been reached, no more can be added
                { 
                    cout << "Sorry the max amount of activites for the party (10) has already been reached." << endl; 
                }

                else 
                {
                    cout << "\nEnter the name of the activity you want to add: " << endl; // user inputs the number that corresponds with wanted activity
                    cout << "Activity List:" << endl;
                    for(int i = 0; i < numActs; i++)
                    {
                        cout << i+1 << ". " << actArray[i] << endl;
                    }

                    cin.ignore(); 
                    getline(cin, newActivity);
                    actArray[numActs] = newActivity; // Placing the new activity in the array
                    numActs++; // Incrementing the number of Activites
                }

                break;

            case 2: // Removing an activity

                int removalChoiceAct;
                
                if (numActs == 0) // When there are no activites in the arrary
                { 
                    cout << "Sorry there are no activites to be removed." << endl;
                }

                else 
                {
                    cout << "Which activity would you like to remove? Enter in an number." << endl;
                    cout << "Activity List:" << endl;
                    for(int i = 0; i < numActs; i++) // Activity List so far
                    {
                        cout << i+1 << ". " << actArray[i] << endl; 
                    }

                    cin >> removalChoiceAct;
                    while (!cin|| removalChoiceAct < 1 || removalChoiceAct > numActs)
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize> :: max(), '\n');
                        cout << "Your input was not valid." << endl;
                        cin >> removalChoiceAct;
                    }

                    // put user validation for an integer (from 1 to max guest -1) here. 

                    for (int i = removalChoiceAct - 1; i < numActs; i++)
                    {
                        actArray[i] = actArray[i+1]; // This will move each element from the right to the left.

                    }

                    numActs--; // Decrementing the number of activities when one is removed

                }

                break;

            case 3: // Modify Activites

            int modifyChoiceActivity;

            if (numActs == 0) // When there are no activities in the arrary to modify
                { 
                    cout << "Sorry there are no activities to be modified." << endl;
                }

                else 
                {
                    cout << "Which activity would you like to modify? Enter in an number." << endl;
                    cout << "List of Activites:" << endl;
                    for(int i = 0; i < numActs; i++) // Activity List 
                    {
                        cout << i+1 << ". " << actArray[i] << endl; 
                    }

                    cin >> modifyChoiceActivity;

                    while (modifyChoiceActivity < 1 || modifyChoiceActivity > numActs) // User Validation 
                    {
                        cout << "Sorry, your input was not valid." << endl; 
                        cin >> modifyChoiceActivity;

                    } // user validation for an number (from 1 to max guest -1) here. 

                    cout << "What would you like the change the activity to?" << endl;
                    cin.ignore();
                    getline(cin, actArray [modifyChoiceActivity- 1]); // This will enter into the array what the user wants to change the name to
                    

                }
                

                break;

                case 4: 
                cout << "Exiting Activities Menu." << endl;
                break;

                default: 
                {
                    cout << "You did not enter in a valid number option." << endl;
                }

                break;
            } 
            


    } while(activityChoice != 4); // Do wihle loop will continue while they do not choose to exit (4)

return numActs;
}


void printFood(string foodArray[], int foodAmountArray[])
{
    for (int i = 0; i < FOOD_COUNT ; i++)// this will show each line untill the max (4) is reached
    { 
        cout << foodArray[i] << ": "  << foodAmountArray[i] << endl; // Parralell arrays display the food and the amount
    }


}

void saveParty(string guestArray[], string actArray[], string foodArray[], int foodAmountArray[], int numGuests, int numActs)
{
string fileName;
ofstream openingFile; // varaible used to open the file

cout << "\nWhat do you want your file to be named?" << endl; // allowing user to enter in the name they want for the file
cin.ignore();
getline(cin, fileName);

openingFile.open(fileName, ios::app);
if (openingFile.is_open())
    {



        //Saving every array to the file
        for (int i = 0; i < numGuests; i++ )
        {
            openingFile << guestArray[i] << endl;
        }

        for (int i = 0; i < numActs; i++)
        {

            openingFile << actArray[i] << endl;

        }
        for(int i = 0; i < FOOD_COUNT; i++) 
        {
            openingFile << foodArray[i] << endl;
        }
        for(int i = 0; i < FOOD_COUNT; i++) 
        {
            openingFile << foodAmountArray[i] << endl;
        }

        openingFile.close();
    }
        else 
        {
            cout << "Sorry, the file could not be opened." << endl; // Checking to see if the file is opened
        
        }
}

